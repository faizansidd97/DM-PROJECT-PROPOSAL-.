# Introduction
Csharp project with code snippets on Cryptography using the System.Security.Cryptography API
provided by Microsoft built-in functions and classes in Csharp.
It was meant to be used in my playlist of Csharp + Cryptography in Youtube:
[Melar Dev Youtube Channel](https://youtube.com/Melardev)
You can also follow me on social media
- [Twitter](https://twitter.com/melardev) I share a lot of dev/IT/security tips
- [Blog](http://melardev.com) My personal blog
- [Instagram](https://www.instagram.com/melar_dev/) Not very active but hey I may post some banners or maybe myself ....
=======
# TutsCSharpCrypto
Youtube Playlist about using Crypto API in C# https://www.youtube.com/playlist?list=PLfkTJXI2Tk-dOnQiSdG29YHnKL5ViEhjt
Tutoriales de criptografía en C# en Youtube https://www.youtube.com/playlist?list=PLfkTJXI2Tk-dOnQiSdG29YHnKL5ViEhjt
